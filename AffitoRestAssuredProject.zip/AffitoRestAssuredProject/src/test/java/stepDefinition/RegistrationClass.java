package stepDefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationClass {
	@Given("^I get the request from the registration \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_get_the_request_from_the_registration_somethingsomethingsomethingsomethingsomething_and_something(String name, String email, String phonenumber, String countrycode, String password, String location, String strArg1, String strArg2, String strArg3, String strArg4, String strArg5, String strArg6) throws Throwable {
       
    }
    @When("^I trigger the api \"([^\"]*)\"$")
    public void i_trigger_the_api_something(String strArg1) throws Throwable {
       
    }
    @Then("^I verify the reasons$")
    public void i_verify_the_reasons() throws Throwable {
        
    }


}
