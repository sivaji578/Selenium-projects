package Resource;

import Pojo.RegistrationPojo;

public class RegistrationSetData {
	public static RegistrationPojo registratioApi(String name,String countryCode,String email,String phoneNumber,String password,String location)
	{
		RegistrationPojo registrationpojo=new RegistrationPojo();
		registrationpojo.setName(name);
		registrationpojo.setCountryCode(countryCode);
		registrationpojo.setEmail(email);
		registrationpojo.setPhoneNumber(phoneNumber);
		registrationpojo.setPassword(password);
		registrationpojo.setLocation(location);
		return registrationpojo;
	}
}
