package Resource;

import Pojo.LoginPojo;

public class LoginSetData {         
	public static LoginPojo loginSetData(String phoneNumber,String countryCode,String password)
	{
		LoginPojo loginPojo=new LoginPojo();
		loginPojo.setPhoneNumber(phoneNumber);
		loginPojo.setCountryCode(countryCode);
		loginPojo.setPassword(password);
		return loginPojo;
	}
	public static LoginPojo loginRequestOtp(String phoneNumber,String countryCode,String hashKey)
	{
		LoginPojo loginPojo=new LoginPojo();
		loginPojo.setPhoneNumber(phoneNumber);
		loginPojo.setCountryCode(countryCode);
		loginPojo.setHashKey(hashKey);
		return loginPojo;
	}
	public static LoginPojo verifyOtp(String phoneNumber,String countryCode,String hash,String otp)
	{
		LoginPojo loginPojo=new LoginPojo();
		loginPojo.setPhoneNumber(phoneNumber);
		loginPojo.setCountryCode(countryCode);
		loginPojo.setHash(hash);
		loginPojo.setOtp(otp);
		return loginPojo;
	}
	
}
